from sqlalchemy import create_engine,MetaData

#engine=create_engine("mysql+pymysql://root:12345@localhost:3306/vision")
engine=create_engine("mysql+pymysql://obackups:Ciatec#ob#2020@dbcharly.cuzfx89vgben.us-east-1.rds.amazonaws.com:3306/vision")

#conn=engine.connect()

meta_data=MetaData()
