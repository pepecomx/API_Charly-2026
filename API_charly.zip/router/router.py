
## ----

## charly_API
## @cc3s0V1si0n

from ast import Try
import string
from unicodedata import name
from urllib import response
from fastapi import APIRouter,Response,Request,Header,Body
from fastapi.responses import HTMLResponse,JSONResponse

from schema.user_schema import UserSchema,DataUser,DataDispositivos,DataDispositivosVista,User,User_Charly
from jwt_file.function_jwt import write_token,validate_token,expire_date,writeFile
from router.local import key

from config.db import engine
from model.db_model import users,dispositivos, eventosVista,usuarios_c
from typing import List

from cryptography.fernet import Fernet

from datetime import datetime, timedelta

#-----

secret_pwd=Fernet(key)
key2=Fernet.generate_key()
secret_Token=Fernet(key2)

dispositivoAPI=APIRouter()


#-----
 ############### _________________________________________________________
# Regresa datos de usuario "IdUsuario"
@dispositivoAPI.put("/api/actualizaContrasena/", status_code=201)

#@dispositivoAPI.put("/api/actualiza_contrasena/{IdUsuario}", status_code=201)
#def actualiza_contrasena(_IdUsuario:str,_contrasenaActual:str,_contrasenaNueva:str):
async def actualiza_contrasena(*,_IdUsuario: str = Body(...),_contrasenaActual: str = Body(...),_contrasenaNueva: str = Body(...)):    
        #print(contrasena_enc)
    try:
        with engine.connect() as conn: 
            id=conn.execute(usuarios_c.select().where(usuarios_c.c.IdUsuario == _IdUsuario)).first()
            contrasena_enc=secret_pwd.encrypt(_contrasenaNueva.encode("utf-8"))
            datos=conn.execute(usuarios_c.select().where(usuarios_c.c.IdUsuario == _IdUsuario)).first()   
            #c_contrasenaActual_ver=secret_pwd.encrypt(_contrasenaActual.encode("utf-8"))                         
            
            if id!=None:
                print(id)
                # decodifica contraseña almacenda    
                contrasena_int=secret_pwd.decrypt(datos[2].encode("utf-8"))#print (_contrasena) 
                contrasena_int_s = str(contrasena_int.decode())# elimina caracter  'b   byte
                print(_contrasenaActual)
                print(contrasena_int_s)
                
                if (_contrasenaActual==contrasena_int_s):    
                    contrasena_enc=secret_pwd.encrypt(_contrasenaNueva.encode("utf-8")) 
                    token=secret_Token.encrypt(_contrasenaNueva.encode("utf-8"))
                    #print(contrasena_enc)
                    
                    fecha=expire_date(2)
                    result=conn.execute(usuarios_c.update().values(Contrasena=contrasena_enc).where(usuarios_c.c.IdUsuario == _IdUsuario))
                    result_t=conn.execute(usuarios_c.update().values(Token=token).where(usuarios_c.c.IdUsuario == _IdUsuario))
                    result_f=conn.execute(usuarios_c.update().values(FechaExpiracion=fecha).where(usuarios_c.c.IdUsuario == _IdUsuario))
                                
                    #print(result)
                    #print(result_t)
                    #print(result_f)
                    
                    print("Contraseña actualizada correctamente")
                    return JSONResponse(content={"message":"Contraseña actualizada correctamente"},status_code=201)   
                else:
                    print("Contraseña actual no correcta!!")
                    return JSONResponse(content={"message":"Contraseña actual no correcta!!"},status_code=401)
                
            else:
                print("Usuario no encontrado !!")
                return JSONResponse(content={"message":"Usuario no encontrado!!"},status_code=401)
    except: 
        return JSONResponse(content={"message":"Error No identificado!!"},status_code=404) 

#-----
 ############### _________________________________________________________
# Regresa datos de usuario "IdUsuario"
@dispositivoAPI.post("/api/obtieneToken/", status_code=201)
#def obtiene_token(_IdUsuario:str,_contrasena:str):
async def obtiene_token(*,_IdUsuario: str = Body(...),_contrasena: str = Body(...)):     
    print ("obtiene_token" )
    try:    
        with engine.connect() as conn: 
            print ("obtiene_token  sigo aqui" )    
            id=conn.execute(usuarios_c.select().where(usuarios_c.c.IdUsuario == _IdUsuario)).first()       
        
            if id!=None:
                datos=conn.execute(usuarios_c.select().where(usuarios_c.c.IdUsuario == _IdUsuario)).first()                    
                #contrasena_user=secret_pwd.encrypt(_contrasena.encode("utf-8")) 
                contrasena_int=secret_pwd.decrypt(datos[2].encode("utf-8"))
                
                #print (_contrasena) 
                contrasena_int_s = str(contrasena_int.decode())# elimina caracter  'b   byte
                #print(datos[2])
                #print (contrasena_int_s)
                
                if _contrasena==contrasena_int_s:          
                
                    fecha_hoy=expire_date(0) # fecha de hoy
                    
                    print("FECHAS")
                    print(fecha_hoy)           
                    #print(datos[2])  # contraseña usuario
                    #print(datos[3])  # token usuario
                    print(datos[4])  # fecha token
                    
                    if (fecha_hoy<=datos[4]):
                        print("TOKEN OK" )
                        print(datos[3])  # token usuario
                        return datos[3]
                    else :
                        print("Token caducado" )
                        return JSONResponse(content={"message":"Token caducado"},status_code=404)  
                    
                else:
                    print("Contraseña no correcta")  
                    return JSONResponse(content={"message":"Contraseña no correcta!!"},status_code=401)  
            else:
                print("Usuario no encontrado!!")  
                return JSONResponse(content={"message":"Usuario no encontrado!!"},status_code=401)  
    except: 
        return JSONResponse(content={"message":"Error No identificado!!"},status_code=404) 
    finally:
        print ("obtiene_token BD cerrado" )  
        print ("escribiendo archivo" )  
        writeFile("obtiene_token BD cerrado")
        #with open('somefile.txt', 'a') as the_file:
        #    the_file.write('Hello\n')     
        conn.close()
######## **************************




 ############### _________________________________________________________
# Regresa datos SOLICITADOS 
# INTEGRA USUARIO y TOKEN

@dispositivoAPI.post("/api/obtieneEventos/", status_code=201)
#@dispositivoAPI.get("/api/obtiene_datos_2/{IdUsuario}")
#def obtiene_eventos(_IdUsuario:str,_token:str,_fecha:str):
async def obtiene_eventos(*,_IdUsuario: str = Body(...), _token:str= Body(...),_fecha:str= Body(...)):    
    try:
        try:
            #fecha_inicio = datetime.strptime('2022-10-10', '%Y-%m-%d')
            fecha_inicio = str(datetime.strptime(_fecha, '%Y-%m-%d'))
            fecha_fin = str(datetime.strptime(_fecha, '%Y-%m-%d') + timedelta(1))
            print("FECHAS")
            print(fecha_inicio)
            print(fecha_fin)
            #fecha_fin='2022-10-11'
        except: 
            return JSONResponse(content={"message":"Error en fecha!!"},status_code=404) 

        with engine.connect() as conn: 
            id=conn.execute(usuarios_c.select().where(usuarios_c.c.IdUsuario == _IdUsuario)).first()       
        
            if id!=None:
                datos=conn.execute(usuarios_c.select().where(usuarios_c.c.IdUsuario == _IdUsuario)).first()                    
                fecha_hoy=expire_date(0) # fecha de hoy
                

                if (fecha_hoy<=datos[4]):
                    print("TOKEN OK" )
                    #print(datos[3])  # token usuario
                    #realiza operacion solicitada 
                    if  (datos[3]== _token):
                        print("TOKENS IGUALES " )
                        
                        #Realiza operacion solicitada
                        with engine.connect() as conn:

                            SQL="SELECT NombreLinea, NombreSeccion, Accion as clasif, hour(FechaCreacionLocal) as hora,FechaCreacionLocal, count(NombreLinea) as cantidad FROM (SELECT * FROM vision.eventos_vw1 WHERE FechaCreacionLocal BETWEEN " + "'" + fecha_inicio + "'" + " AND " + "'" + fecha_fin + "'" + ") as t1 GROUP BY NombreLinea, NombreSeccion, Accion, hour(FechaCreacionLocal)"
                            print(SQL)
                            result = conn.execute(SQL).fetchall()

                            print("Consulta exitosa") 
                            return result
                    
                        # return datos[3]
                    else:
                        print("TOKEN NO VALIDO!! " ) 
                        return JSONResponse(content={"message":"Token no valido!!"},status_code=404)      
                    
                else :
                    print("Token caducado!!" )
                    return JSONResponse(content={"message":"Token caducado!!"},status_code=404)  
                
            else:
                print("Usuario no correcto!!")  
                return JSONResponse(content={"message":"Usuario no encontrado!!"},status_code=401)  
    except: 
        return JSONResponse(content={"message":"Error No identificado!!"},status_code=404) 
        
 ######## **************************
 
